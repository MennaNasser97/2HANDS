package com.example.a2hands.signupPackage;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.a2hands.R;

public class signUpSetFavTopicsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_set_fav_topics);
    }
}
