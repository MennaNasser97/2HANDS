package com.example.a2hands;

public interface Callback{
    void callbackUser(User user);
}
